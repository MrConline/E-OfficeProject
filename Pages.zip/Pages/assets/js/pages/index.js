﻿$(function() {
    "use strict";
    MorrisArea();
    initDonutChart();
});

$(function() {
    $('.sparkline-pie').sparkline('html', {
        type: 'pie',
        offset: 90,
        width: '138px',
        height: '138px',
        sliceColors: ['#454c56', '#61ccb7', '#5589cd']
    })

    $("#sparkline14").sparkline([8, 2, 3, 7, 6, 5, 2, 1, 4, 8], {
        type: 'line',
        width: '100%',
        height: '28',
        lineColor: '#3f7dc5',
        fillColor: 'transparent',
        spotColor: '#000',
        lineWidth: 1,
        spotRadius: 2,

    });
    $("#sparkline15").sparkline([2, 3, 9, 1, 2, 5, 4, 7, 8, 2], {
        type: 'line',
        width: '100%',
        height: '28',
        lineColor: '#e66990',
        fillColor: 'transparent',
        spotColor: '#000',
        lineWidth: 1,
        spotRadius: 2,
    });

    $('.sparkbar').sparkline('html', {
        type: 'bar',
        height: '100',
        width: '100%',
        barSpacing: '20',
        barColor: '#e56590',
        negBarColor: '#4ac2ae',
        responsive: true,
    });
});

// Morris-chart
function MorrisArea() {
    Morris.Area({
        element: 'area_chart',
        data: [{
                period: '2011',
                Tanzania: 2,
                Kenya: 0,
                Uganda: 0
            }, {
                period: '2012',
                Tanzania: 31,
                Kenya: 10,
                Uganda: 5
            }, {
                period: '2013',
                Tanzania: 15,
                Kenya: 28,
                Uganda: 23
            }, {
                period: '2014',
                Tanzania: 45,
                Kenya: 12,
                Uganda: 7
            }, {
                period: '2015',
                Tanzania: 20,
                Kenya: 32,
                Uganda: 55
            }, {
                period: '2016',
                ATanzania: 39,
                Kenya: 67,
                Uganda: 20
            }, {
                period: '2017',
                Tanzania: 20,
                Kenya: 9,
                Uganda: 5
            }

        ],
        lineColors: ['#a890d3', '#FFC107', '#666666'],
        xkey: 'period',
        ykeys: ['Tanzania', 'Kenya', 'Uganda'],
        labels: ['Tanzania', 'Kenya', 'Uganda'],
        pointSize: 0,
        lineWidth: 0,
        resize: true,
        fillOpacity: 0.8,
        behaveLikeLine: true,
        gridLineColor: '#e0e0e0',
        hideHover: 'auto'
    });
    Morris.Area({
        element: 'm_area_chart',
        data: [{
                period: '2011',
                Mbwana: 45,
                Nunirah: 75,
                Nandimba: 18
            }, {
                period: '2012',
                Mbwana: 130,
                Nunirah: 110,
                Nandimba: 82
            }, {
                period: '2013',
                Mbwana: 80,
                Nunirah: 60,
                Nandimba: 85
            }, {
                period: '2014',
                Mbwana: 78,
                Nunirah: 205,
                Nandimba: 135
            }, {
                period: '2015',
                Mbwana: 180,
                Nunirah: 124,
                Nandimba: 140
            }, {
                period: '2016',
                Mbwana: 105,
                Nunirah: 100,
                Nandimba: 85
            },
            {
                period: '2017',
                Mbwana: 210,
                Nunirah: 180,
                Nandimba: 120
            }
        ],
        xkey: 'period',
        ykeys: ['Mbwana', 'Nunirah', 'Nandimba'],
        labels: ['Mbwana', 'Nunirah', 'Nandimba'],
        pointSize: 3,
        fillOpacity: 0,
        pointStrokeColors: ['#007bff', '#28a745', '#ffc107'],
        behaveLikeLine: true,
        gridLineColor: '#e0e0e0',
        lineWidth: 2,
        hideHover: 'auto',
        lineColors: ['#007bff', '#28a745', '#ffc107'],
        resize: true

    });
}

function initDonutChart() {
    Morris.Donut({
        element: 'donut_chart',
        data: [{
                label: 'Chrome',
                value: 37
            }, {
                label: 'Firefox',
                value: 30
            }, {
                label: 'Safari',
                value: 18
            }, {
                label: 'Opera',
                value: 12
            },
            {
                label: 'Other',
                value: 3
            }
        ],
        colors: ['#93e3ff', '#b0dd91', '#ffe699', '#f8cbad', '#a4a4a4'],
        formatter: function(y) {
            return y + '%'
        }
    });
}
//======
$(window).on('scroll', function() {
    $('.card .sparkline').each(function() {
        var imagePos = $(this).offset().top;

        var topOfWindow = $(window).scrollTop();
        if (imagePos < topOfWindow + 400) {
            $(this).addClass("pullUp");
        }
    });
});

/*VectorMap Init*/
$(function() {
    $('#world-map-markers2').vectorMap({
        map: 'world_mill_en',
        scaleColors: ['#ea6c9c', '#ea6c9c'],
        normalizeFunction: 'polynomial',
        hoverOpacity: 0.7,
        hoverColor: false,
        regionStyle: {
            initial: {
                fill: '#e0e0e0'
            }
        },
        markerStyle: {
            initial: {
                r: 15,
                'fill': '#313740',
                'fill-opacity': 0.9,
                'stroke': '#fff',
                'stroke-width': 5,
                'stroke-opacity': 0.5
            },

            hover: {
                'stroke': '#fff',
                'fill-opacity': 1,
                'stroke-width': 5
            }
        },
        backgroundColor: 'transparent',
        markers: [
            { latLng: [37.09, -95.71], name: 'Tanzania' },
            { latLng: [51.16, 10.45], name: 'kenya' },
            { latLng: [-25.27, 133.77], name: 'Uganda' },
            { latLng: [56.13, -106.34], name: 'Canada' },
            { latLng: [20.59, 78.96], name: 'India' },
            { latLng: [55.37, -3.43], name: 'United Kingdom' },
        ]
    });
});