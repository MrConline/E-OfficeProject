'use strict';
$(document).ready(function() {
    $('.table').footable({
        "paging": {
            "enabled": true
        },
        "sorting": {
            "enabled": true
        }
    });
});