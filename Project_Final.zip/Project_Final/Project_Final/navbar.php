<style>
    .link{
		background-color: whitesmoke;
		color: black;
		font-size :20px;
	}
</style>

<nav id="sidebar" class='mx-lt-5 bg-dark'>

	<div class="sidebar-list">
		<a href="index.php?page=home" class="nav-item nav-home"><span class='icon-field'><i class="fa fa-home"></i></span> Home</a>
		<a href="index.php?page=files" class="nav-item nav-files"><span class='icon-field'><i class="fa fa-file"></i></span> Files</a>
		<?php if ($_SESSION['login_type'] == 1) : ?>
			<a href="index.php?page=users" class="nav-item nav-users"><span class='icon-field'><i class="fa fa-users"></i></span> Users</a>
		<?php endif; ?>


		<p><a class="nav-item nav-building" data-toggle="collapse" href="#collapseExample" role="button" aria-expanded="false" aria-controls="collapseExample">
		<span class='icon-field'><i class="ri-apps-fill"></i></span> Apps</a>
		</p>
		<div class="collapse" id="collapseExample">
			<div class="card card-body">
				<a href="index.php?page=mail" class="link"><span class='icon-field'><i class="ri-mail-fill"></i></span>Inbox</a>
				<a href="index.php?page=compose" class="link"><span class='icon-field'><i class="ri-mail-fill"></i></span>Compose Mail</a>
				<a href="index.php?page=chart" class="link"><span class='icon-field'><i class="ri-mail-fill"></i></span>Single mail</a>
				<a href="index.php?page=chart" class="link"><span class='icon-field'><i class="ri-mail-fill"></i></span>Draft</a>
				<a href="index.php?page=chart" class="link"><span class='icon-field'><i class="ri-chat-2-fill"></i></span>Important</a>
				<a href="index.php?page=chart" class="link"><span class='icon-field'><i class="ri-chat-2-fill"></i></span>Bin</a>
				
			</div>
		</div>
		<a href="index.php?page=calender" class="nav-item nav-building"><span class='icon-field'><i class="ri-calendar-2-line"></i></span> Calendar</a>
		<a href="#" class="nav-item nav-building"><span class='icon-field'><i class="ri-building-4-line"></i></span> MyOffice</a>
		<a href="#" class="nav-item nav-lock"><span class='icon-field'><i class="ri-lock-2-fill"></i></span> Authentication</a>
	</div>

</nav>

<script>
	$('.nav-<?php echo isset($_GET['page']) ? $_GET['page'] : '' ?>').addClass('active')
</script>