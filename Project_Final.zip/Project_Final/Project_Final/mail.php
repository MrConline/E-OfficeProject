<style>
	.custom-menu {
        z-index: 1000;
	    position: absolute;
	    background-color: #ffffff;
	    border: 1px solid #0000001c;
	    border-radius: 5px;
	    padding: 8px;
	    min-width: 13vw;
}
a.custom-menu-list {
    width: 100%;
    display: flex;
    color: #4c4b4b;
    font-weight: 600;
    font-size: 1em;
    padding: 1px 11px;
}
	span.card-icon {
    position: absolute;
    font-size: 3em;
    bottom: .2em;
    color: #ffffff80;
}
.file-item{
	cursor: pointer;
}
a.custom-menu-list:hover,.file-item:hover,.file-item.active {
    background: #80808024;
}
table th,td{
	/*border-left:1px solid gray;*/
}
a.custom-menu-list span.icon{
		width:1em;
		margin-right: 5px
}
</style>
<!-- Favicon-->
<link rel="icon" href="favicon.ico" type="image/x-icon">
    <!-- Font Icon -->
    <link rel="stylesheet" href="mafele/plugins/bootstrap/css/bootstrap.min.css">
    <!-- Custom Css -->
    <link rel="stylesheet" href="lucas/css/main.css">
    <link rel="stylesheet" href="lucas/css/inbox.css">
    <link rel="stylesheet" href="lucas/css/color_skins.css">
<nav aria-label="breadcrumb ">
  <ol class="breadcrumb">
  <li class="breadcrumb-item text-dark">Inbox</li>
  </ol>
</nav>
<div class="containe-fluid">
	<?php include('db_connect.php') ;
	$files = $conn->query("SELECT f.*,u.name as uname FROM files f inner join users u on u.id = f.user_id where  f.is_public = 1 order by date(f.date_updated) desc");

	?>
	<section class="content inbox">
    <div class="container-fluid">
        <div class="block-header">
            <div class="row clearfix">
                <div class="col-lg-5 col-md-5 col-sm-12">
                    <!-- <h2>Inbox</h2>
                    <ul class="breadcrumb padding-0">
                        <li class="breadcrumb-item"><a href="index.html"><i class="zmdi zmdi-home"></i></a></li>                        
                        <li class="breadcrumb-item active">Inbox</li>
                    </ul> -->
                </div>            
                <div class="col-lg-7 col-md-7 col-sm-12">
                    <div class="input-group m-b-0">                
                        <input type="text" class="form-control" placeholder="Search...">
                        <span class="input-group-addon"><i class="zmdi zmdi-search"></i></span>
                    </div>
                </div>
            </div>
        </div>
        <div class="row clearfix">
            <div class="col-lg-12">
                <div class="card">
                    <div class="body">
                        <ul class="nav nav-tabs padding-0">
                            <li class="nav-item"><a class="nav-link active" data-toggle="tab" href="#Primary">Primary</a></li>        
                            <li class="nav-item"><a class="nav-link" data-toggle="tab" href="#Social">Social</a></li>
                            <li class="nav-item"><a class="nav-link" data-toggle="tab" href="#Updates">Updates</a></li>
                        </ul>
                    </div>
                </div>            
                <div class="tab-content">
                    <div class="tab-pane active" id="Primary">
                        <div class="card">
                            <div class="header">
                                <h2><strong>Today</strong></h2>
                                <ul class="header-dropdown">
                                    <li class="dropdown"> <a href="javascript:void(0);" class="dropdown-toggle" data-toggle="dropdown" role="button" aria-haspopup="true" aria-expanded="false"> <i class="zmdi zmdi-label"></i></a>
                                        <ul class="dropdown-menu slideUp">
                                            <li><a href="javascript:void(0);">Important</a></li>
                                            <li><a href="javascript:void(0);">Social</a></li>
                                            <li><a href="javascript:void(0);">Bank Statements</a></li>
                                            <li role="separator" class="divider"></li>
                                            <li><a href="javascript:void(0);">Create a folder</a></li>
                                        </ul>
                                    </li>
                                    <li><a href="javascript:void(0);"><i class="zmdi zmdi-delete"></i></a></li>
                                    <li class="dropdown"> <a href="javascript:void(0);" class="dropdown-toggle" data-toggle="dropdown" role="button" aria-haspopup="true" aria-expanded="false"> <i class="zmdi zmdi-more"></i> </a>
                                        <ul class="dropdown-menu slideUp">
                                            <li><a href="javascript:void(0);">Select All</a></li>
                                            <li><a href="javascript:void(0);">Another action</a></li>
                                            <li><a href="javascript:void(0);">Something else</a></li>
                                        </ul>
                                    </li>                                    
                                </ul>
                            </div>
                            <div class="body">
                                <ul class="list-unstyled mail_list">
                                    <li class="media">
                                        <div class="controls">
                                            <div class="checkbox">
                                                <input type="checkbox" id="basic_checkbox_2">
                                                <label for="basic_checkbox_2"></label>
                                            </div>
                                            <a href="javascript:void(0);" class="favourite col-amber" data-toggle="active"><i class="zmdi zmdi-star"></i></a>
                                        </div>                                        
                                        <div class="media-body">
                                            <div class="thumb"> <img src="lucas/images/xs/avatar1.jpg" class="rounded-circle" alt=""> </div>
                                            <div class="media-heading">
                                                <a href="mail-single.html">John Smith</a>
                                                <span class="badge badge-warning">Shop</span>
                                                <small class="float-right text-muted">3 Mar</small>
                                            </div>
                                            <p class="msg"><span class="m-r-10">[ThemeForest]</span>is a long established fact that a reader will be distracted by the readable content of a page when looking at its layout.</p>                                
                                        </div>
                                    </li>
                                    <li class="media unread">
                                        <div class="controls">
                                            <div class="checkbox">
                                                <input type="checkbox" id="basic_checkbox_2">
                                                <label for="basic_checkbox_2"></label>
                                            </div>
                                            <a href="javascript:void(0);" class="favourite col-amber" data-toggle="active"><i class="zmdi zmdi-star"></i></a>
                                        </div>
                                        <div class="media-body">
                                            <div class="thumb"> <img src="lucas/images/xs/avatar2.jpg" class="rounded-circle" alt=""> </div>
                                            <div class="media-heading">
                                                <a href="mail-single.html">Maryam Amiri</a>
                                                <span class="badge badge-danger">Google</span>
                                                <small class="float-right text-muted">3 Mar</small>
                                            </div>
                                            <p class="msg"><span class="m-r-10">[Google]</span>Lorem Ipsum is simply dummy text of the printing and typesetting industry.</p>
                                        </div>
                                    </li>
                                    <li class="media">
                                        <div class="controls">
                                            <div class="checkbox">
                                                <input type="checkbox" id="basic_checkbox_3">
                                                <label for="basic_checkbox_3"></label>
                                            </div>
                                            <a href="javascript:void(0);" class="favourite text-muted" data-toggle="active"><i class="zmdi zmdi-star-outline"></i></a>
                                        </div>
                                        <div class="media-body">
                                            <div class="thumb"> <img src="lucas/images/xs/avatar3.jpg" class="rounded-circle" alt=""> </div>
                                            <div class="media-heading">
                                                <a href="mail-single.html">Fidel Tonn</a>
                                                <span class="badge badge-success">Work</span>
                                                <small class="float-right text-muted">3 Mar</small>
                                            </div>
                                            <p class="msg"><span class="m-r-10">[WrapTheme]</span>If you are going to use a passage of Lorem Ipsum, you need to be sure</p>
                                        </div>
                                    </li>
                                    <li class="media">
                                        <div class="controls">
                                            <div class="checkbox">
                                                <input type="checkbox" id="basic_checkbox_4">
                                                <label for="basic_checkbox_4"></label>
                                            </div>
                                            <a href="javascript:void(0);" class="favourite text-muted" data-toggle="active"><i class="zmdi zmdi-star-outline"></i></a>
                                        </div>
                                        <div class="media-body">
                                            <div class="thumb"> <img src="lucas/images/xs/avatar4.jpg" class="rounded-circle" alt=""> </div>
                                            <div class="media-heading">
                                                <a href="mail-single.html" class="m-r-10">Gary Camara</a>
                                                <small class="float-right text-muted">3 Mar</small>
                                            </div>
                                            <p class="msg"><span class="m-r-10">[Awwwards]</span>There are many variations of passages of Lorem Ipsum available, but the majority </p>
                                        </div>
                                    </li>
                                </ul>
                            </div>
                            <div class="header">
                                <h2><strong>Yesterday</strong></h2>
                            </div>
                            <div class="body">
                                <ul class="list-unstyled mail_list">
                                    <li class="media">
                                        <div class="controls">
                                            <div class="checkbox">
                                                <input type="checkbox" id="y1">
                                                <label for="y1"></label>
                                            </div>
                                            <a href="javascript:void(0);" class="favourite col-amber" data-toggle="active"><i class="zmdi zmdi-star"></i></a>
                                        </div>
                                        <div class="media-body">
                                            <div class="thumb"> <img src="lucas/images/xs/avatar10.jpg" class="rounded-circle" alt=""> </div>
                                            <div class="media-heading">
                                                <a href="mail-single.html">Fidel Tonn</a>
                                                <small class="float-right text-muted">2 Mar</small>
                                            </div>
                                            <p class="msg"><span class="m-r-10">[ThemeForest]</span>is a long established fact that a reader will be distracted by the readable content of a page when looking at its layout.</p>                                
                                        </div>
                                    </li>
                                    <li class="media unread">
                                        <div class="controls">
                                            <div class="checkbox">
                                                <input type="checkbox" id="y2">
                                                <label for="y2"></label>
                                            </div>
                                            <a href="javascript:void(0);" class="favourite col-amber" data-toggle="active"><i class="zmdi zmdi-star"></i></a>
                                        </div>
                                        <div class="media-body">
                                            <div class="thumb"> <img src="lucas/images/xs/avatar9.jpg" class="rounded-circle" alt=""> </div>
                                            <div class="media-heading">
                                                <a href="mail-single.html">Maryam Amiri</a>
                                                <span class="badge badge-danger">Google</span>
                                                <small class="float-right text-muted">2 Mar</small>
                                            </div>
                                            <p class="msg"><span class="m-r-10">[Google]</span>Lorem Ipsum is simply dummy text of the printing and typesetting industry.</p>
                                        </div>
                                    </li>
                                </ul>
                            </div>
                            <div class="header">
                                <h2><strong>Week</strong> ago</h2>
                            </div>
                            <div class="body">
                                <ul class="list-unstyled mail_list">
                                    <li class="media">
                                        <div class="controls">
                                            <div class="checkbox">
                                                <input type="checkbox" id="basic_checkbox_2">
                                                <label for="basic_checkbox_2"></label>
                                            </div>
                                            <a href="javascript:void(0);" class="favourite col-amber" data-toggle="active"><i class="zmdi zmdi-star"></i></a>
                                        </div>                                        
                                        <div class="media-body">
                                            <div class="thumb"> <img src="lucas/images/xs/avatar1.jpg" class="rounded-circle" alt=""> </div>
                                            <div class="media-heading">
                                                <a href="mail-single.html">John Smith</a>
                                                <small class="float-right text-muted">1 Mar</small>
                                            </div>
                                            <p class="msg"><span class="m-r-10">[ThemeForest]</span>is a long established fact that a reader will be distracted by the readable content of a page when looking at its layout.</p>                                
                                        </div>
                                    </li>
                                    <li class="media">
                                        <div class="controls">
                                            <div class="checkbox">
                                                <input type="checkbox" id="basic_checkbox_2">
                                                <label for="basic_checkbox_2"></label>
                                            </div>
                                            <a href="javascript:void(0);" class="favourite col-amber" data-toggle="active"><i class="zmdi zmdi-star"></i></a>
                                        </div>
                                        <div class="media-body">
                                            <div class="thumb"> <img src="lucas/images/xs/avatar2.jpg" class="rounded-circle" alt=""> </div>
                                            <div class="media-heading">
                                                <a href="mail-single.html">Maryam Amiri</a>
                                                <span class="badge badge-danger">Google</span>
                                                <small class="float-right text-muted">1 Mar</small>
                                            </div>
                                            <p class="msg"><span class="m-r-10">[Google]</span>Lorem Ipsum is simply dummy text of the printing and typesetting industry.</p>
                                        </div>
                                    </li>
                                    <li class="media">
                                        <div class="controls">
                                            <div class="checkbox">
                                                <input type="checkbox" id="basic_checkbox_3">
                                                <label for="basic_checkbox_3"></label>
                                            </div>
                                            <a href="javascript:void(0);" class="favourite text-muted" data-toggle="active"><i class="zmdi zmdi-star-outline"></i></a>
                                        </div>
                                        <div class="media-body">
                                            <div class="thumb"> <img src="lucas/images/xs/avatar3.jpg" class="rounded-circle" alt=""> </div>
                                            <div class="media-heading">
                                                <a href="mail-single.html">Fidel Tonn</a>
                                                <span class="badge badge-success">Work</span>
                                                <small class="float-right text-muted">1 Mar</small>
                                            </div>
                                            <p class="msg"><span class="m-r-10">[WrapTheme]</span>If you are going to use a passage of Lorem Ipsum, you need to be sure</p>
                                        </div>
                                    </li>
                                    <li class="media">
                                        <div class="controls">
                                            <div class="checkbox">
                                                <input type="checkbox" id="basic_checkbox_4">
                                                <label for="basic_checkbox_4"></label>
                                            </div>
                                            <a href="javascript:void(0);" class="favourite text-muted" data-toggle="active"><i class="zmdi zmdi-star-outline"></i></a>
                                        </div>
                                        <div class="media-body">
                                            <div class="thumb"> <img src="lucas/images/xs/avatar4.jpg" class="rounded-circle" alt=""> </div>
                                            <div class="media-heading">
                                                <a href="mail-single.html" class="m-r-10">Gary Camara</a>
                                                <small class="float-right text-muted">28 Feb</small>
                                            </div>
                                            <p class="msg"><span class="m-r-10">[ThemeMakker]</span>There are many variations of passages of Lorem Ipsum available, but the majority </p>
                                        </div>
                                    </li>
                                    <li class="media">
                                        <div class="controls">
                                            <div class="checkbox">
                                                <input type="checkbox" id="y1">
                                                <label for="y1"></label>
                                            </div>
                                            <a href="javascript:void(0);" class="favourite col-amber" data-toggle="active"><i class="zmdi zmdi-star"></i></a>
                                        </div>
                                        <div class="media-body">
                                            <div class="thumb"> <img src="lucas/images/xs/avatar10.jpg" class="rounded-circle" alt=""> </div>
                                            <div class="media-heading">
                                                <a href="mail-single.html">Fidel Tonn</a>
                                                <small class="float-right text-muted">28 Feb</small>
                                            </div>
                                            <p class="msg"><span class="m-r-10">[ThemeForest]</span>is a long established fact that a reader will be distracted by the readable content of a page when looking at its layout.</p>                                
                                        </div>
                                    </li>
                                    <li class="media">
                                        <div class="controls">
                                            <div class="checkbox">
                                                <input type="checkbox" id="y2">
                                                <label for="y2"></label>
                                            </div>
                                            <a href="javascript:void(0);" class="favourite col-amber" data-toggle="active"><i class="zmdi zmdi-star"></i></a>
                                        </div>
                                        <div class="media-body">
                                            <div class="thumb"> <img src="lucas/images/xs/avatar9.jpg" class="rounded-circle" alt=""> </div>
                                            <div class="media-heading">
                                                <a href="mail-single.html">Maryam Amiri</a>
                                                <span class="badge badge-danger">Google</span>
                                                <small class="float-right text-muted">27 Feb</small>
                                            </div>
                                            <p class="msg"><span class="m-r-10">[Google]</span>Lorem Ipsum is simply dummy text of the printing and typesetting industry.</p>
                                        </div>
                                    </li>
                                    <li class="media">
                                        <div class="controls">
                                            <div class="checkbox">
                                                <input type="checkbox" id="y3">
                                                <label for="y3"></label>
                                            </div>
                                            <a href="javascript:void(0);" class="favourite text-muted" data-toggle="active"><i class="zmdi zmdi-star-outline"></i></a>
                                        </div>
                                        <div class="media-body">
                                            <div class="thumb"> <img src="lucas/images/xs/avatar8.jpg" class="rounded-circle" alt=""> </div>
                                            <div class="media-heading">
                                                <a href="mail-single.html">Tim Hank</a>
                                                <span class="badge badge-success">Work</span>
                                                <small class="float-right text-muted">27 Feb</small>
                                            </div>
                                            <p class="msg"><span class="m-r-10">[ThemeMakker]</span>If you are going to use a passage of Lorem Ipsum, you need to be sure</p>
                                        </div>
                                    </li>
                                    <li class="media">
                                        <div class="controls">
                                            <div class="checkbox">
                                                <input type="checkbox" id="y4">
                                                <label for="y4"></label>
                                            </div>
                                            <a href="javascript:void(0);" class="favourite text-muted" data-toggle="active"><i class="zmdi zmdi-star-outline"></i></a>
                                        </div>
                                        <div class="media-body">
                                            <div class="thumb"> <img src="lucas/images/xs/avatar7.jpg" class="rounded-circle" alt=""> </div>
                                            <div class="media-heading">
                                                <a href="mail-single.html" class="m-r-10">Frank Camly</a>
                                                <small class="float-right text-muted">27 Feb</small>
                                            </div>
                                            <p class="msg"><span class="m-r-10">[Awwwards]</span>There are many variations of passages of Lorem Ipsum available, but the majority </p>
                                        </div>
                                    </li>
                                </ul>
                            </div>
                        </div>
                    </div>
                    <div class="tab-pane" id="Social">
                        <div class="card">
                            <div class="header">
                                <h2><strong>Today</strong></h2>
                                <ul class="header-dropdown">
                                    <li class="dropdown"> <a href="javascript:void(0);" class="dropdown-toggle" data-toggle="dropdown" role="button" aria-haspopup="true" aria-expanded="false"> <i class="zmdi zmdi-label"></i></a>
                                        <ul class="dropdown-menu slideUp">
                                            <li><a href="javascript:void(0);">Important</a></li>
                                            <li><a href="javascript:void(0);">Social</a></li>
                                            <li><a href="javascript:void(0);">Bank Statements</a></li>
                                            <li role="separator" class="divider"></li>
                                            <li><a href="javascript:void(0);">Create a folder</a></li>
                                        </ul>
                                    </li>
                                    <li><a href="javascript:void(0);"><i class="zmdi zmdi-delete"></i></a></li>
                                    <li class="dropdown"> <a href="javascript:void(0);" class="dropdown-toggle" data-toggle="dropdown" role="button" aria-haspopup="true" aria-expanded="false"> <i class="zmdi zmdi-more"></i> </a>
                                        <ul class="dropdown-menu slideUp">
                                            <li><a href="javascript:void(0);">Action</a></li>
                                            <li><a href="javascript:void(0);">Another action</a></li>
                                            <li><a href="javascript:void(0);">Something else</a></li>
                                        </ul>
                                    </li>                                    
                                </ul>
                            </div>
                            <div class="body">
                                <ul class="list-unstyled mail_list">
                                    <li class="media">
                                        <div class="controls">
                                            <div class="checkbox">
                                                <input type="checkbox" id="s1">
                                                <label for="s1"></label>
                                            </div>
                                            <a href="javascript:void(0);" class="favourite col-amber" data-toggle="active"><i class="zmdi zmdi-star"></i></a>
                                        </div>                                        
                                        <div class="media-body">
                                            <div class="thumb"> <img src="lucas/images/xs/avatar1.jpg" class="rounded-circle" alt=""> </div>
                                            <div class="media-heading">
                                                <a href="mail-single.html">Alexander</a>                                                
                                                <small class="float-right text-muted">3 Mar</small>
                                            </div>
                                            <p class="msg"><span class="m-r-10">[Facebook]</span>is a long established fact that a reader will be distracted by the readable content of a page when looking at its layout.</p>                                
                                        </div>
                                    </li>
                                    <li class="media unread">
                                        <div class="controls">
                                            <div class="checkbox">
                                                <input type="checkbox" id="s2">
                                                <label for="s2"></label>
                                            </div>
                                            <a href="javascript:void(0);" class="favourite col-amber" data-toggle="active"><i class="zmdi zmdi-star"></i></a>
                                        </div>
                                        <div class="media-body">
                                            <div class="thumb"> <img src="lucas/images/xs/avatar2.jpg" class="rounded-circle" alt=""> </div>
                                            <div class="media-heading">
                                                <a href="mail-single.html">Sophia</a>                                                
                                                <small class="float-right text-muted">3 Mar</small>
                                            </div>
                                            <p class="msg"><span class="m-r-10">[Twitter]</span>Lorem Ipsum is simply dummy text of the printing and typesetting industry.</p>
                                        </div>
                                    </li>
                                    <li class="media">
                                        <div class="controls">
                                            <div class="checkbox">
                                                <input type="checkbox" id="s3">
                                                <label for="s3"></label>
                                            </div>
                                            <a href="javascript:void(0);" class="favourite text-muted" data-toggle="active"><i class="zmdi zmdi-star-outline"></i></a>
                                        </div>
                                        <div class="media-body">
                                            <div class="thumb"> <img src="lucas/images/xs/avatar3.jpg" class="rounded-circle" alt=""> </div>
                                            <div class="media-heading">
                                                <a href="mail-single.html">Fidel</a>                                                
                                                <small class="float-right text-muted">3 Mar</small>
                                            </div>
                                            <p class="msg"><span class="m-r-10">[Facebook]</span>If you are going to use a passage of Lorem Ipsum, you need to be sure</p>
                                        </div>
                                    </li>                                    
                                </ul>
                            </div>
                        </div>
                    </div>
                    <div class="tab-pane" id="Updates">
                        <div class="card">
                            <div class="header">
                                <h2><strong>Today</strong></h2>
                                <ul class="header-dropdown">
                                    <li class="dropdown"> <a href="javascript:void(0);" class="dropdown-toggle" data-toggle="dropdown" role="button" aria-haspopup="true" aria-expanded="false"> <i class="zmdi zmdi-label"></i></a>
                                        <ul class="dropdown-menu slideUp">
                                            <li><a href="javascript:void(0);">Important</a></li>
                                            <li><a href="javascript:void(0);">Social</a></li>
                                            <li><a href="javascript:void(0);">Bank Statements</a></li>
                                            <li role="separator" class="divider"></li>
                                            <li><a href="javascript:void(0);">Create a folder</a></li>
                                        </ul>
                                    </li>
                                    <li><a href="javascript:void(0);"><i class="zmdi zmdi-delete"></i></a></li>
                                    <li class="dropdown"> <a href="javascript:void(0);" class="dropdown-toggle" data-toggle="dropdown" role="button" aria-haspopup="true" aria-expanded="false"> <i class="zmdi zmdi-more"></i> </a>
                                        <ul class="dropdown-menu slideUp">
                                            <li><a href="javascript:void(0);">Action</a></li>
                                            <li><a href="javascript:void(0);">Another action</a></li>
                                            <li><a href="javascript:void(0);">Something else</a></li>
                                        </ul>
                                    </li>                                    
                                </ul>
                            </div>
                            <div class="body">
                                <ul class="list-unstyled mail_list">
                                    <li class="media">
                                        <div class="controls">
                                            <div class="checkbox">
                                                <input type="checkbox" id="u1">
                                                <label for="u1"></label>
                                            </div>
                                            <a href="javascript:void(0);" class="favourite col-amber" data-toggle="active"><i class="zmdi zmdi-star"></i></a>
                                        </div>                                        
                                        <div class="media-body">
                                            <div class="thumb"> <img src="lucas/images/xs/avatar3.jpg" class="rounded-circle" alt=""> </div>
                                            <div class="media-heading">
                                                <a href="mail-single.html">Alexander</a>                                                
                                                <small class="float-right text-muted">3 Mar</small>
                                            </div>
                                            <p class="msg"><span class="m-r-10">[Google]</span>is a long established fact that a reader will be distracted by the readable content of a page when looking at its layout.</p>                                
                                        </div>
                                    </li>
                                    <li class="media unread">
                                        <div class="controls">
                                            <div class="checkbox">
                                                <input type="checkbox" id="u2">
                                                <label for="u2"></label>
                                            </div>
                                            <a href="javascript:void(0);" class="favourite col-amber" data-toggle="active"><i class="zmdi zmdi-star"></i></a>
                                        </div>
                                        <div class="media-body">
                                            <div class="thumb"> <img src="lucas/images/xs/avatar4.jpg" class="rounded-circle" alt=""> </div>
                                            <div class="media-heading">
                                                <a href="mail-single.html">Sophia</a>                                                
                                                <small class="float-right text-muted">3 Mar</small>
                                            </div>
                                            <p class="msg"><span class="m-r-10">[Behance]</span>Lorem Ipsum is simply dummy text of the printing and typesetting industry.</p>
                                        </div>
                                    </li>
                                    <li class="media">
                                        <div class="controls">
                                            <div class="checkbox">
                                                <input type="checkbox" id="u3">
                                                <label for="u3"></label>
                                            </div>
                                            <a href="javascript:void(0);" class="favourite text-muted" data-toggle="active"><i class="zmdi zmdi-star-outline"></i></a>
                                        </div>
                                        <div class="media-body">
                                            <div class="thumb"> <img src="lucas/images/xs/avatar5.jpg" class="rounded-circle" alt=""> </div>
                                            <div class="media-heading">
                                                <a href="mail-single.html">Fidel</a>                                                
                                                <small class="float-right text-muted">3 Mar</small>
                                            </div>
                                            <p class="msg"><span class="m-r-10">[Bootstrap]</span>If you are going to use a passage of Lorem Ipsum, you need to be sure</p>
                                        </div>
                                    </li>
                                    <li class="media">
                                        <div class="controls">
                                            <div class="checkbox">
                                                <input type="checkbox" id="u4">
                                                <label for="u4"></label>
                                            </div>
                                            <a href="javascript:void(0);" class="favourite col-amber" data-toggle="active"><i class="zmdi zmdi-star"></i></a>
                                        </div>                                        
                                        <div class="media-body">
                                            <div class="thumb"> <img src="lucas/images/xs/avatar6.jpg" class="rounded-circle" alt=""> </div>
                                            <div class="media-heading">
                                                <a href="mail-single.html">Alexander</a>                                                
                                                <small class="float-right text-muted">3 Mar</small>
                                            </div>
                                            <p class="msg"><span class="m-r-10">[Bootstrap]</span>is a long established fact that a reader will be distracted by the readable content of a page when looking at its layout.</p>                                
                                        </div>
                                    </li>
                                    <li class="media unread">
                                        <div class="controls">
                                            <div class="checkbox">
                                                <input type="checkbox" id="u5">
                                                <label for="u5"></label>
                                            </div>
                                            <a href="javascript:void(0);" class="favourite col-amber" data-toggle="active"><i class="zmdi zmdi-star"></i></a>
                                        </div>
                                        <div class="media-body">
                                            <div class="thumb"> <img src="lucas/images/xs/avatar7.jpg" class="rounded-circle" alt=""> </div>
                                            <div class="media-heading">
                                                <a href="mail-single.html">Sophia</a>                                                
                                                <small class="float-right text-muted">3 Mar</small>
                                            </div>
                                            <p class="msg"><span class="m-r-10">[Grunt]</span>Lorem Ipsum is simply dummy text of the printing and typesetting industry.</p>
                                        </div>
                                    </li>
                                </ul>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
     </div>
</section>
</div>
<script src="assets/bundles/libscripts.bundle.js"></script>
<script src="assets/bundles/vendorscripts.bundle.js"></script>
<script src="assets/bundles/mainscripts.bundle.js"></script>
<script>
	//FILE
	$('.file-item').bind("contextmenu", function(event) { 
    event.preventDefault();

    $('.file-item').removeClass('active')
    $(this).addClass('active')
    $("div.custom-menu").hide();
    var custom =$("<div class='custom-menu file'></div>")
        custom.append($('#menu-file-clone').html())
        custom.find('.download').attr('data-id',$(this).attr('data-id'))
    custom.appendTo("body")
	custom.css({top: event.pageY + "px", left: event.pageX + "px"});

	
	$("div.file.custom-menu .download").click(function(e){
		e.preventDefault()
		window.open('download.php?id='+$(this).attr('data-id'))
	})

	

})
	$(document).bind("click", function(event) {
    $("div.custom-menu").hide();
    $('#file-item').removeClass('active')

});
	$(document).keyup(function(e){

    if(e.keyCode === 27){
        $("div.custom-menu").hide();
    $('#file-item').removeClass('active')

    }
})
</script>