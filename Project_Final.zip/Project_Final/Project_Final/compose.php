

<link rel="icon" href="favicon.ico" type="image/x-icon">
<!-- Font Icon -->
<link rel="stylesheet" href="lucas/plugins/bootstrap/css/bootstrap.min.css">
<!-- Custom Css -->
<link  rel="stylesheet" href="lucas/css/main.css">
<link rel="stylesheet" href="lucas/css/inbox.css">
<link rel="stylesheet" href="lucas/css/color_skins.css">
<nav aria-label="breadcrumb ">
  <ol class="breadcrumb">
  <li class="breadcrumb-item text-dark">Compose</li>
  </ol>
</nav>
<div class="containe-fluid">
	<?php include('db_connect.php') ;
	$files = $conn->query("SELECT f.*,u.name as uname FROM files f inner join users u on u.id = f.user_id where  f.is_public = 1 order by date(f.date_updated) desc");

	?>
<section class="content inbox">
    <div class="container-fluid">+
        <div class="block-header">
            <div class="row clearfix">
                <div class="col-lg-5 col-md-5 col-sm-12">
                    <!-- <h2>Compose</h2> -->
                    <ul class="breadcrumb p-l-0 p-b-0 ">
                      <!-- <br><br><br>
                        <li class="breadcrumb-item active">Compose</li> -->
                    </ul>
                </div>            
                <div class="col-lg-7 col-md-7 col-sm-12">
                    <div class="input-group m-b-0">                
                        <input type="text" class="form-control" placeholder="Search...">
                        <span class="input-group-addon"><i class="zmdi zmdi-search"></i></span>
                    </div>
                </div>
            </div>
        </div>
        <div class="row clearfix">
            <div class="col-lg-12">
                <div class="card">
                    <div class="body m-b-10">
                        <div class="form-group form-float">
                            <input type="text" class="form-control" placeholder="To:">
                        </div>
                        <div class="form-group form-float">
                            <input type="text" class="form-control" placeholder="Subject">
                        </div>
                        <div class="form-group form-float">
                            <input type="text" class="form-control" placeholder="CC">
                        </div>
                    </div>
                    <div class="body">
                        <textarea id="ckeditor">
                           
                        </textarea>
                        <button type="button" class="btn btn-primary btn-round waves-effect m-t-20">Send Message</button>                        
                    </div>
                </div>
            </div>
        </div>
    </div>
</section>